from tkinter import *
from tkinter.ttk import *
from tkinter import font, messagebox
from tkinter import colorchooser
from tkinter import filedialog
import os
import tempfile


# Functionality Part

def change_theme(bg_color,fg_color):
    textarea.config(bg=bg_color,fg=fg_color)

def toolbar():
    if show_toolbar.get() == False:
        tool_bar.pack_forget()
    if show_toolbar.get() == True:
        textarea.pack_forget()
        tool_bar.pack(fill=X)
        textarea.pack(fill=BOTH, expand=1)


def statusbar():
    if show_statusbar.get() == False:
        status_bar.pack_forget()
    else:
        status_bar.pack()


def find():
    def find_words():
        textarea.tag_remove('match', 1.0, END)
        start_pos = '1.0'
        word = findentryField.get()
        if word:
            while True:  # to highlight all occurrences of the word
                start_pos = textarea.search(word, start_pos, stopindex=END)  # 1.0
                if not start_pos:  # To come out of the start position after there's nothing in the start position
                    break
                end_pos = f'{start_pos}+{len(word)}c'  # 1.0+1c
                textarea.tag_add('match', start_pos, end_pos)

                textarea.tag_config('match', foreground='white', background='black')
                start_pos = end_pos

    def replace_text():
        word = findentryField.get()
        replaceword = replaceentryField.get()
        content = textarea.get(1.0, END)
        new_content = content.replace(word, replaceword)
        textarea.delete(1.0, END)
        textarea.insert(1.0, new_content)

    # GUI for find
    root1 = Toplevel()

    # Pop up window
    root1.title('Find')
    root1.geometry('450x250+500+200')
    root1.resizable(0, 0)

    # The label frame
    labelFrame = LabelFrame(root1, text='Find/Replace')
    labelFrame.pack(pady=50)

    findLabel = Label(labelFrame, text='Find')
    findLabel.grid(row=0, column=0, padx=5, pady=5)
    findentryField = Entry(labelFrame)
    findentryField.grid(row=0, column=1, padx=5, pady=5)

    replaceLabel = Label(labelFrame, text='Replace')
    replaceLabel.grid(row=1, column=0, padx=5, pady=5)
    replaceentryField = Entry(labelFrame)
    replaceentryField.grid(row=1, column=1, padx=5, pady=5)

    findButton = Button(labelFrame, text='FIND', command=find_words)
    findButton.grid(row=2, column=0, padx=5, pady=5)

    replaceButton = Button(labelFrame, text='REPLACE', command=replace_text)
    replaceButton.grid(row=2, column=1, padx=5, pady=5)

    # when you exit find window the highlighted text becomes normal
    def doSomething():
        textarea.tag_remove('match', 1.0, END)
        root1.destroy()

    root1.protocol('WM_DELETE_WINDOW', doSomething)
    root1.mainloop()


def statusBarFunction(event):
    if textarea.edit_modified():
        words = len(textarea.get(0.0, END).split())
        characters = len(textarea.get(0.0, 'end-1c').replace(' ',
                                                             ''))  # end-1c to not count the last that is the new line character and replace is to replace spaces
        status_bar.config(text=f'Characters: {characters} Words: {words}')

    textarea.edit_modified(False)


# New
url = ''


def new_file(event=None):
    global url
    url = ''
    textarea.delete(0.0, END)


def open_file(event=None):
    global url
    url = filedialog.askopenfilename(initialdir=os.getcwd, title='Select File', filetypes=(('Text File', 'txt'),
                                                                                           ('All Files',
                                                                                            '*.*')))  # Import os
    if url != '':
        data = open(url, 'r')
        textarea.insert(0.0, data.read())
    root.title(os.path.basename(url))  # updating the file name


def printout(event=None):
    file = tempfile.mktemp('.txt')
    open(file, 'w').write(textarea.get(1.0, END))
    os.startfile(file, 'print')


def save_file(event=None):
    if url == '':
        save_url = filedialog.asksaveasfile(mode='w', defaultextension='.txt', filetypes=(('Text File', 'txt'),
                                                                                          ('All Files', '*.*')))
        if save_url is None:
            pass
        else:
            content = textarea.get(0.0, END)
            save_url.write(content)
            save_url.close()

    else:
        content = textarea.get(0.0, END)
        file = open(url, 'w')
        file.write(content)


def saveas_file(event=None):
    save_url = filedialog.asksaveasfile(mode='w', defaultextension='.txt', filetypes=(('Text File', 'txt'),
                                                                                      ('All Files', '*.*')))

    content = textarea.get(0.0, END)
    save_url.write(content)
    save_url.close()
    if url != '':
        os.remove(url)


def iexit(event=None):
    if textarea.edit_modified():
        result = messagebox.askyesnocancel('Warning', 'Do you want to save the file?')
        if result is True:  # If yes
            if url != '':  # If it already has a path or is an existing file
                content = textarea.get(0.0, END)
                file = open(url, 'w')
                file.write(content)
                root.destroy()
            else:
                content = textarea.get(0.0, END)
                save_url = filedialog.asksaveasfile(mode='w', defaultextension='.txt', filetypes=(('Text File', 'txt'),
                                                                                                  ('All Files', '*.*')))

                save_url.write(content)
                save_url.close()
                root.destroy()

        elif result is False:
            root.destroy()

        else:
            pass

    else:
        root.destroy()


# Buttons
fontsize = 12
fontstyle = 'Arial'


def font_style(event):
    global fontstyle
    fontstyle = font_family_variable.get()
    textarea.config(font=(fontstyle, fontsize))


def font_size(event):
    global fontsize
    fontsize = size_variable.get()
    textarea.config(font=(fontstyle, fontsize))


def bold_text():
    text_property = font.Font(font=textarea['font']).actual()
    if text_property['weight'] == 'normal':
        textarea.config(font=(fontstyle, fontsize, 'bold'))
    if text_property['weight'] == 'bold':
        textarea.config(font=(fontstyle, fontsize, 'normal'))


def italic_text():
    text_property = font.Font(font=textarea['font']).actual()
    if text_property['slant'] == 'roman':
        textarea.config(font=(fontstyle, fontsize, 'italic'))

    if text_property['slant'] == 'italic':
        textarea.config(font=(fontstyle, fontsize, 'roman'))


def underline_text():
    text_property = font.Font(font=textarea['font']).actual()
    if text_property['underline'] == 0:
        textarea.config(font=(fontstyle, fontsize, 'underline'))

    if text_property['underline'] == 1:
        textarea.config(font=(fontstyle, fontsize))


def color_select():
    color = colorchooser.askcolor()
    textarea.config(fg=color[1])


def align_right():
    data = textarea.get(0.0, END)
    textarea.tag_config('right', justify=RIGHT)
    textarea.delete(0.0, END)
    textarea.insert(INSERT, data, 'right')


def align_left():
    data = textarea.get(0.0, END)
    textarea.tag_config('left', justify=LEFT)
    textarea.delete(0.0, END)
    textarea.insert(INSERT, data, 'left')


def align_center():
    data = textarea.get(0.0, END)
    textarea.tag_config('center', justify=CENTER)
    textarea.delete(0.0, END)
    textarea.insert(INSERT, data, 'center')


# GUI Part
root = Tk()
root.title('Notepad')
root.geometry('1200x620+10+10')

# Makes the window size unchangeable
# root.resizable(False, False)

# creating menu bar
menubar = Menu(root)
root.config(menu=menubar)

# Toolbar section
tool_bar = Label(root)
tool_bar.pack(side=TOP, fill=X)
font_families = font.families()

# combobox from .ttk and using state = 'readonly
font_family_variable = StringVar()
fontfamily_Combobox = Combobox(tool_bar, width=30, values=font_families, state='readonly',
                               textvariable=font_family_variable)
# setting default font
fontfamily_Combobox.current(font_families.index('Arial'))
fontfamily_Combobox.grid(row=0, column=0, padx=5)

# combobox for text size
size_variable = IntVar()
# to get the indexing we need to convert it to a tuple
font_size_Combobox = Combobox(tool_bar, width=14, textvariable=size_variable, state='readonly',
                              values=tuple(range(8, 81)))
font_size_Combobox.current(4)
font_size_Combobox.grid(row=0, column=1, padx=5)

# Scrollbar
scrollbar = Scrollbar(root)
scrollbar.pack(side=RIGHT, fill=Y)
# Creating Text Area
textarea = Text(root, yscrollcommand=scrollbar.set, font=('arial', 12), undo=True)
# Using expand = True to make the text area fill the window
textarea.pack(fill=BOTH, expand=True)
# Making the scroll bar functional
scrollbar.config(command=textarea.yview)

textarea.bind('<<Modified>>', statusBarFunction)
fontfamily_Combobox.bind("<<ComboboxSelected>>", font_style)
font_size_Combobox.bind('<<ComboboxSelected>>', font_size)

# File Menu Section
filemenu = Menu(menubar, tearoff=False)
menubar.add_cascade(label='File', menu=filemenu)

newImage = PhotoImage(file='new.png')
openImage = PhotoImage(file='open.png')
saveImage = PhotoImage(file='save.png')
saveasImage = PhotoImage(file='save_as.png')
exitImage = PhotoImage(file='exit.png')
printImage = PhotoImage(file='print.png')

filemenu.add_command(label='New', accelerator='Ctrl+n', image=newImage, compound=LEFT, command=new_file)
filemenu.add_command(label='Open', accelerator='Ctrl+o', image=openImage, compound=LEFT, command=open_file)
filemenu.add_command(label='Save', accelerator='Ctrl+s', image=saveImage, compound=LEFT, command=save_file)
filemenu.add_command(label='Save as', accelerator='Ctrl+Shift+s', image=saveasImage, compound=LEFT, command=saveas_file)
filemenu.add_command(label='Print',accelerator='Ctrl+p', image=printImage, compound=LEFT, command=printout)
filemenu.add_separator()
filemenu.add_command(label='Exit', accelerator='Ctrl+q', image=exitImage, compound=LEFT, command=iexit)

# View Menu Section
show_toolbar = BooleanVar()
show_statusbar = BooleanVar()
toolbarImage = PhotoImage(file='tool_bar.png')
statusbarImage = PhotoImage(file='status_bar.png')

viewmenu = Menu(menubar, tearoff=False)
viewmenu.add_checkbutton(label="Tool Bar", variable=show_toolbar, onvalue=True, offvalue=False, image=toolbarImage,
                         compound=LEFT, command=toolbar)
show_toolbar.set(True)
viewmenu.add_checkbutton(label="Status Bar", variable=show_statusbar, onvalue=True, offvalue=False,
                         image=statusbarImage, compound=LEFT, command=statusbar)
show_statusbar.set(True)
menubar.add_cascade(label='View', menu=viewmenu)

# Edit Menu Section
editmenu = Menu(menubar, tearoff=False)
menubar.add_cascade(label='Edit', menu=editmenu)

undoImage = PhotoImage(file='undo.png')
cutImage = PhotoImage(file='cut.png')
copyImage = PhotoImage(file='copy.png')
pasteImage = PhotoImage(file='paste.png')
clear_allImage = PhotoImage(file='delete.png')
findImage = PhotoImage(file='find.png')
selectallImage = PhotoImage(file='selectall.png')

editmenu.add_command(label='Undo', accelerator='Ctrl+z', image=undoImage, compound=LEFT)
editmenu.add_command(label='Copy', accelerator='Ctrl+c', image=copyImage, compound=LEFT,
                     command=lambda: textarea.event_generate('<Control c>'))
editmenu.add_command(label='Cut', accelerator='Ctrl+x', image=cutImage, compound=LEFT,
                     command=lambda: textarea.event_generate('<Control x>'))
editmenu.add_command(label='Paste', accelerator='Ctrl+v', image=pasteImage, compound=LEFT,
                     command=lambda: textarea.event_generate('<Control v>'))
editmenu.add_separator()
editmenu.add_command(label='Find', accelerator='Ctrl+Alt+x', image=findImage, compound=LEFT, command=find)
editmenu.add_separator()
editmenu.add_command(label='Clear All', accelerator='Ctrl+Alt+x', image=pasteImage, compound=LEFT,
                     command=lambda: textarea.delete(0.0, END))
editmenu.add_command(label='Select All', accelerator='Ctrl+a', image=selectallImage, compound=LEFT)

# Themes Section
themesmenu = Menu(menubar, tearoff=False)
menubar.add_cascade(label='Themes', menu=themesmenu)

theme_choice = StringVar()
lightImage = PhotoImage(file='light_default.png')
darkImage = PhotoImage(file='dark.png')
monokaiImage = PhotoImage(file='monokai.png')
pinkImage = PhotoImage(file='pink.png')
themesmenu.add_radiobutton(label='Light Default', image=lightImage, variable=theme_choice, compound=LEFT,
                           command=lambda: change_theme('white', 'black'))
themesmenu.add_radiobutton(label='Dark', image=darkImage, variable=theme_choice, compound=LEFT,
                           command=lambda: change_theme('gray20', 'white'))
themesmenu.add_radiobutton(label='Monokai', image=monokaiImage, variable=theme_choice, compound=LEFT,
                           command=lambda: change_theme('orange', 'black'))
themesmenu.add_radiobutton(label='Pink', image=pinkImage, variable=theme_choice, compound=LEFT,
                           command=lambda: change_theme('pink', 'black'))

# button section
boldImage = PhotoImage(file='bold.png')
boldButton = Button(tool_bar, image=boldImage, command=bold_text)
boldButton.grid(row=0, column=2, padx=5)

italicImage = PhotoImage(file='italic.png')
italicButton = Button(tool_bar, image=italicImage, command=italic_text)
italicButton.grid(row=0, column=3, padx=5)

underlineImage = PhotoImage(file='underline.png')
underlineButton = Button(tool_bar, image=underlineImage, command=underline_text)
underlineButton.grid(row=0, column=4, padx=5)

fontColorImage = PhotoImage(file='font_color.png')
fontColorButton = Button(tool_bar, image=fontColorImage, command=color_select)
fontColorButton.grid(row=0, column=5, padx=5)

leftAlignImage = PhotoImage(file='left.png')
leftAlignButton = Button(tool_bar, image=leftAlignImage, command=align_left)
leftAlignButton.grid(row=0, column=6, padx=5)

centerAlignImage = PhotoImage(file='center.png')
centerAlignButton = Button(tool_bar, image=centerAlignImage, command=align_center)
centerAlignButton.grid(row=0, column=7, padx=5)

rightAlignImage = PhotoImage(file='right.png')
rightAlignButton = Button(tool_bar, image=rightAlignImage, command=align_right)
rightAlignButton.grid(row=0, column=8, padx=5)

status_bar = Label(root, text='Status Bar')
status_bar.pack(side=BOTTOM)

root.bind("<Control-o>", open_file)
root.bind("<Control-n>", new_file)
root.bind("<Control-s>", save_file)
root.bind("<Control-Shift-s>", saveas_file)
root.bind("<Control-q>", iexit)
root.bind("<Control-p>", printout)

root.mainloop()
